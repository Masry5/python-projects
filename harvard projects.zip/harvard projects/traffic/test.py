

src='C:\Users\user\OneDrive - Faculty of Computers and Information\Desktop\harvard\harvard project\traffic\gtsrb'