from nltk import word_tokenize

s = "this is nothing."
k=word_tokenize(s)

print(k)