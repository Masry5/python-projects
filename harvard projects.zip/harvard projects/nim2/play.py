from nim1 import train, play

ai = train(20000)
play(ai)
3