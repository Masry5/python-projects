
print(7*60*60)
