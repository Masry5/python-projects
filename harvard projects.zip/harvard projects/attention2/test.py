i=[[1,5],[6,2]]
print(i.index([6,2]))